package com.example.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.model.Contact;
import com.example.demo.model.Employee;


public interface ContactService 
{
  public String addmess(Contact cc);


}